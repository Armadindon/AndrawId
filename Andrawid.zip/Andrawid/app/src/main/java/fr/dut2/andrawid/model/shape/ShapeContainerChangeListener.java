package fr.dut2.andrawid.model.shape;

public interface ShapeContainerChangeListener {
    void onShapeContainerChange();
}
