package fr.dut2.andrawid.model;

public interface ShapeContainerChangeListener {
    void onShapeContainerChange();
}
